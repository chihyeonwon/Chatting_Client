package com.djdjsn.emochat.utils.res;

public class ColorRes {

    public static int getEmojiCardColor() {
        return 0xFFDDDDDD;
    }

    public static int getEmojiCardColorHighlighted() {
        return 0xFFCCCCCC;
    }


}
